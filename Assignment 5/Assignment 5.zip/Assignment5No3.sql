CREATE OR REPLACE VIEW items_ordered AS
SELECT item_id, product_name, item_price, quantity
FROM order_items JOIN products ON order_items.product_id = products.product_id;