DROP DATABASE IF EXISTS assignment;
CREATE DATABASE assignment;
USE assignment;

CREATE TABLE student (
  student_id        INT            PRIMARY KEY   UNIQUE AUTO_INCREMENT,
  student_name      VARCHAR(100)	   NOT NULL      UNIQUE,
  address			VARCHAR(100)		NOT NULL,
  email				VARCHAR(100)		NOT NULL
);

CREATE TABLE subject (
	classes_id		INT,
    classes			VARCHAR(100)	NOT NULL,
    major			VARCHAR(45)		NOT NULL
);

INSERT INTO assignment.student
VALUES (1, 'Joe Green', '124 Main St', 'Joe@school.edu'); 

INSERT INTO assignment.subject
VALUES (1, 'IT1025/MATH1200/IT1050', 'programming');

INSERT INTO assignment.student
VALUES (2, 'Sue Smith', '345 Second St', 'Sue@school.edu');

INSERT INTO assignment.subject
VALUES (2, 'IT1025/IT1050/IT2351', 'programming');

INSERT INTO assignment.student 
VALUES (3, 'Nick Green', '45 York Rd', 'Nick@school.edu');

INSERT INTO assignment.subject
VALUES (3, 'IT1025', 'networking');

INSERT INTO assignment.student
VALUES (4, 'Andy Andrews', '600 5th Ave', 'Andy@school.edu');

INSERT INTO assignment.subject
VALUES (4, 'IT1025/IT1050', 'networking');

INSERT INTO assignment.student
VALUES (5, 'Liam Neloson', '12345 Jameson Dr', 'Liam@school.edu');

INSERT INTO assignment.subject
VALUES (5, 'IT1050', 'programming');

INSERT INTO assignment.student
VALUES (6, 'Mya James', '452 Maple Rd','Mya@school.edu');

INSERT INTO assignment.subject
VALUES (6, 'IT2351','networking');

INSERT INTO assignment.student
VALUES (7, 'Cadance Laney', '678 James St', 'Cadance@school.edu');

INSERT INTO assignment.subject
VALUES (7, 'IT1025/IT1050', 'networking');