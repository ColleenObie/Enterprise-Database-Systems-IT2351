SELECT student_id, student_name, address, email, classes, major
FROM student INNER JOIN subject
ON student.student_id = subject.classes_id