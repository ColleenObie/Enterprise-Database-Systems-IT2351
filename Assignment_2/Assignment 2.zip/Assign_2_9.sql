/*This query is to update the unit price by 10% for all items with a unit price > 17*/
UPDATE items
SET unit_price = unit_price + .10
WHERE unit_price > 17;