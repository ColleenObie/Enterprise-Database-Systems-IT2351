/*This query is meant to concatenate the names then join the information from the two tables and order it.*/
SELECT CONCAT(customer_first_name,',' ,customer_last_name) AS Name, customer_city, customer_state, order_date, shipped_date
FROM customers JOIN orders ON customers.customer_id = orders.customer_id
ORDER BY customer_state, customer_city, customer_last_name, customer_first_name