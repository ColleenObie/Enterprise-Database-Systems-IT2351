/*I had to combine two tables so I used the inner join so that these rows were shown in detail*/
SELECT customer_id, order_date, item_id, order_qty
FROM orders INNER JOIN order_details
ON orders.order_id = order_details.order_id
