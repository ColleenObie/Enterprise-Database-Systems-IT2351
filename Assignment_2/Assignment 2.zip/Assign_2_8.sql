/* This query is to insert a row of data to the pre-existing customers table*/
INSERT INTO customers
VALUES (00865, 'Colleen', 'Overbaugh', '45454 Lee Dr','Parma', 'OH', '44129', '4407832110', '4407757554');
SELECT customer_id, customer_first_name, customer_last_name, customer_address, customer_city
FROM customers
WHERE customer_first_name = 'Colleen'