/*This query is to output all orders from Ohio and including the customer's names and titles purchased*/
SELECT customer_state, customer_first_name, customer_last_name, title
FROM items, customers
WHERE customer_state= 'Oh'