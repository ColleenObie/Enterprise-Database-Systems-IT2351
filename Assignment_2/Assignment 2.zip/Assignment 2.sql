/*This query it to use the join method to join two tables then sort them from title followed by artist
The primary key is joined with the foreign key after 'ON'.*/
SELECT title, artist, unit_price, order_qty FROM items INNER JOIN order_details ON items.item_id = order_details.item_id
ORDER BY title, artist