/*In this query I am replacing customer_id with customer name and modifying the code so that
the results are shown*/
SELECT customer_first_name, customer_last_name, order_date, order_qty, artist
FROM orders
INNER JOIN order_details
ON orders.order_id = order_details.order_id
JOIN items 
ON items.item_id = order_details.item_id
JOIN customers
ON customers.customer_id = orders.order_id;

UPDATE order_details
SET item_id = item_id;
UPDATE orders
SET customer_id = customer_id