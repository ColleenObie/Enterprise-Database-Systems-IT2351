/*In this script I am creating a script that calls a stored procedure to provide 
three statements about the transacion for a company called FedUP*/
USE ap;
DROP PROCEDURE IF EXISTS test;

DELIMITER //

CREATE PROCEDURE test()
BEGIN
  DECLARE sql_error INT DEFAULT FALSE;
  
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    SET sql_error = TRUE;

  START TRANSACTION;
  
  UPDATE invoices
  SET vendor_id = 100
  WHERE vendor_id = 101;

  DELETE FROM vendors
  WHERE vendor_id = 101;

  UPDATE vendors
  SET vendor_name = 'FedUP'
  WHERE vendor_id = 100;

  IF sql_error = FALSE THEN COMMIT;
    SELECT 'Committed';
  ELSE
    ROLLBACK;
    SELECT 'Rolled Back';
  END IF;
END//

DELIMITER ;

CALL test();