/*In this query, I created a script that stores a procedure called test. This script includes two 
statements as a transaction that will delete the row with an invoice ID of 114.*/
USE ap;
DROP PROCEDURE IF EXISTS test;

DELIMITER //

CREATE PROCEDURE test()
BEGIN
  DECLARE sql_error INT DEFAULT FALSE;
  
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    SET sql_error = TRUE;

  START TRANSACTION;
  
  DELETE FROM invoice_line_items
  WHERE invoice_id = 98;

  DELETE FROM invoices
  WHERE invoice_id = 98;

  COMMIT;
  
  IF sql_error = FALSE THEN COMMIT;
    SELECT 'Committed';
  ELSE
    ROLLBACK;
    SELECT 'Rolled Back';
  END IF;
END//

DELIMITER ;

CALL test();