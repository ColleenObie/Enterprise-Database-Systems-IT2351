/*This query calculates the discount amount after the discount percentage*/
SELECT list_price, discount_percent,
ROUND(list_price * discount_percent / 100,2) AS "Discount_Amount"
FROM products