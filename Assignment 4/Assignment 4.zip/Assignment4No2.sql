/*This query returns information about the domain and email address*/
SELECT email_address,
CHAR_LENGTH(email_address) AS Length, 
LOCATE("@", email_address) AS "@",
SUBSTRING(email_address, 1, LOCATE('@', email_address) - 1) AS "USERNAME",
SUBSTRING(email_address, LOCATE('@', email_address) + 1) AS "DOMAIN"
FROM customers