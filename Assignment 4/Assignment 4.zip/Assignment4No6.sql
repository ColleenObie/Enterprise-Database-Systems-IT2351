/*In this query I created a view of the data. The discount amount and final amounts for the quantity of the
product in the order is displayed in the results. I keep getting an error with the CREATE VIEW
since the table already exists after creating it the furst time before syntax errors and changes. 
It kept telling me I needded to specify for the order_id
so I decieded to specify with the first letter of the table since it looks like a lot of other people do
that in MySQL. I personally think it helps to prevent confusion while coding as well*/
CREATE VIEW order_item_products AS 
SELECT O.order_id, O.order_date, O.tax_amount, O.ship_date, product_name, item_price, discount_amount, (item_price-discount_amount) 
AS final_price, quantity, (item_price-discount_amount)*quantity AS item_total
FROM Orders O, Order_Items OI, Products P
WHERE O.order_id = OI.order_id AND OI.product_id = P.product_id;