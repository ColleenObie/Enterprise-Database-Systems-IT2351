/*This query shows the highest and lowest prices by product for each category*/
SELECT categories.category_name, products.product_name,
SUM((order_items.item_price + order_items.discount_amount) * order_items.quantity) AS 'total_sales',
FIRST_VALUE(products.product_name) OVER (PARTITION BY categories.category_name 
ORDER BY SUM((order_items.item_price + order_items.discount_amount) * order_items.quantity) DESC RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS 'highest_sales',
LAST_VALUE(products.product_name) OVER (PARTITION BY categories.category_name
ORDER BY SUM((order_items.item_price + order_items.discount_amount) * order_items.quantity) DESC RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS 'lowest_sales'
FROM categories JOIN products ON categories.category_id = products.category_id
JOIN order_items ON order_items.product_id = products.product_id
GROUP BY categories.category_id, categories.category_name, products.product_id, products.product_name