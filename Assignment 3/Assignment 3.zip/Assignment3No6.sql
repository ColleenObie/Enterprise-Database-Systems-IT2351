/*This adds 3 columns for each customer then calculates the order total*/

SELECT customers.email_address, orders.order_id,
SUM(order_items.item_price) AS 'Order Total' FROM customers
JOIN orders ON customers.customer_id = orders.customer_id
JOIN order_items ON orders.order_id = order_items.order_id
GROUP BY customers.customer_id