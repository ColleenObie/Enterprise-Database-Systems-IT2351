/*I did a count for the number of orders and the sum of the shipping amount.
Results are separate per line of code*/
SELECT COUNT(*) AS number_of_orders FROM orders;
SELECT SUM(ship_amount) AS 'Ship Value' FROM orders