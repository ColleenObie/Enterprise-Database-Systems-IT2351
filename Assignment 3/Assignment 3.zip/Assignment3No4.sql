/*In this query, I showed the quantity for the total purchased in each category with a ROLLUP
and the IF GROUPING included*/
SELECT IF(GROUPING(product_name) = 1, 'category_name', product_name) AS 'Name',
SUM(order_items.quantity) AS 'Total' FROM categories
JOIN products ON categories.category_id = products.category_id
JOIN order_items ON products.product_id = order_items.product_id
GROUP BY categories.category_name, products.product_name WITH ROLLUP