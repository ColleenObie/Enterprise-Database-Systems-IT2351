/*I am joining two tables to show the category name and to show each row with products
and the cost of the most expensive product*/
SELECT category_name, COUNT(products.product_id) list_price FROM categories 
JOIN products ON categories.category_id = products.category_id
GROUP BY categories.category_id HAVING MAX(products.list_price)
ORDER BY MAX(product_id)